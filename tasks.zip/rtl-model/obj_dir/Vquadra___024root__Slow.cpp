// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vquadra.h for the primary calling header

#include "Vquadra__pch.h"
#include "Vquadra__Syms.h"
#include "Vquadra___024root.h"

void Vquadra___024root___ctor_var_reset(Vquadra___024root* vlSelf);

Vquadra___024root::Vquadra___024root(Vquadra__Syms* symsp, const char* v__name)
    : VerilatedModule{v__name}
    , vlSymsp{symsp}
 {
    // Reset structure values
    Vquadra___024root___ctor_var_reset(this);
}

void Vquadra___024root::__Vconfigure(bool first) {
    if (false && first) {}  // Prevent unused
}

Vquadra___024root::~Vquadra___024root() {
}
