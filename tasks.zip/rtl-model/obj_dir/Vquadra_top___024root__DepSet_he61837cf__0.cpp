// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vquadra_top.h for the primary calling header

#include "Vquadra_top__pch.h"
#include "Vquadra_top___024root.h"

void Vquadra_top___024root___eval_act(Vquadra_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___eval_act\n"); );
}

VL_INLINE_OPT void Vquadra_top___024root___nba_sequent__TOP__0(Vquadra_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___nba_sequent__TOP__0\n"); );
    // Init
    VlWide<3>/*95:0*/ __Vtemp_2;
    VlWide<3>/*95:0*/ __Vtemp_3;
    VlWide<3>/*95:0*/ __Vtemp_4;
    // Body
    vlSelf->quadra_top__DOT__dv_p2 = ((IData)(vlSelf->rst_b) 
                                      && (IData)(vlSelf->quadra_top__DOT__dv_p1));
    vlSelf->y_dv = vlSelf->quadra_top__DOT__dv_p2;
    vlSelf->quadra_top__DOT__dv_p1 = ((IData)(vlSelf->rst_b) 
                                      && (IData)(vlSelf->quadra_top__DOT__dv_p0));
    vlSelf->quadra_top__DOT__y_p4 = ((IData)(vlSelf->rst_b)
                                      ? (0xffffffU 
                                         & ((0x7fffffffU 
                                             & VL_EXTENDS_II(31,28, vlSelf->quadra_top__DOT__sum_p4)) 
                                            + vlSelf->quadra_top__DOT__a_p2))
                                      : 0U);
    vlSelf->y = vlSelf->quadra_top__DOT__y_p4;
    vlSelf->quadra_top__DOT__dv_p0 = ((IData)(vlSelf->rst_b) 
                                      && (IData)(vlSelf->x_dv));
    __Vtemp_2[0U] = vlSelf->quadra_top__DOT__frac_p0;
    __Vtemp_2[1U] = 0U;
    __Vtemp_2[2U] = 0U;
    __Vtemp_3[0U] = vlSelf->quadra_top__DOT__frac_p0;
    __Vtemp_3[1U] = 0U;
    __Vtemp_3[2U] = 0U;
    VL_MUL_W(3, __Vtemp_4, __Vtemp_2, __Vtemp_3);
    if (vlSelf->rst_b) {
        vlSelf->quadra_top__DOT__sum_p4 = (0xfffffffU 
                                           & (vlSelf->quadra_top__DOT__ab_p3 
                                              + vlSelf->quadra_top__DOT__bb_p3));
        vlSelf->quadra_top__DOT__ab_p3 = (0xfffffffU 
                                          & (IData)(
                                                    (0x3ffffffffULL 
                                                     & ((QData)((IData)(vlSelf->quadra_top__DOT__a_p2)) 
                                                        * 
                                                        (0x3ffffffffULL 
                                                         & (((QData)((IData)(
                                                                             __Vtemp_4[1U])) 
                                                             << 0x20U) 
                                                            | (QData)((IData)(
                                                                              __Vtemp_4[0U]))))))));
        vlSelf->quadra_top__DOT__bb_p3 = (0xfffffffU 
                                          & (vlSelf->quadra_top__DOT__a_p2 
                                             * vlSelf->quadra_top__DOT__frac_p2));
        vlSelf->quadra_top__DOT__frac_p2 = vlSelf->quadra_top__DOT__frac_p0;
    } else {
        vlSelf->quadra_top__DOT__sum_p4 = 0U;
        vlSelf->quadra_top__DOT__ab_p3 = 0U;
        vlSelf->quadra_top__DOT__bb_p3 = 0U;
        vlSelf->quadra_top__DOT__frac_p2 = 0U;
    }
    vlSelf->quadra_top__DOT__a_p2 = 0U;
}

void Vquadra_top___024root___eval_nba(Vquadra_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___eval_nba\n"); );
    // Body
    if ((1ULL & vlSelf->__VnbaTriggered.word(0U))) {
        Vquadra_top___024root___nba_sequent__TOP__0(vlSelf);
    }
}

void Vquadra_top___024root___eval_triggers__act(Vquadra_top___024root* vlSelf);

bool Vquadra_top___024root___eval_phase__act(Vquadra_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___eval_phase__act\n"); );
    // Init
    VlTriggerVec<1> __VpreTriggered;
    CData/*0:0*/ __VactExecute;
    // Body
    Vquadra_top___024root___eval_triggers__act(vlSelf);
    __VactExecute = vlSelf->__VactTriggered.any();
    if (__VactExecute) {
        __VpreTriggered.andNot(vlSelf->__VactTriggered, vlSelf->__VnbaTriggered);
        vlSelf->__VnbaTriggered.thisOr(vlSelf->__VactTriggered);
        Vquadra_top___024root___eval_act(vlSelf);
    }
    return (__VactExecute);
}

bool Vquadra_top___024root___eval_phase__nba(Vquadra_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___eval_phase__nba\n"); );
    // Init
    CData/*0:0*/ __VnbaExecute;
    // Body
    __VnbaExecute = vlSelf->__VnbaTriggered.any();
    if (__VnbaExecute) {
        Vquadra_top___024root___eval_nba(vlSelf);
        vlSelf->__VnbaTriggered.clear();
    }
    return (__VnbaExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vquadra_top___024root___dump_triggers__nba(Vquadra_top___024root* vlSelf);
#endif  // VL_DEBUG
#ifdef VL_DEBUG
VL_ATTR_COLD void Vquadra_top___024root___dump_triggers__act(Vquadra_top___024root* vlSelf);
#endif  // VL_DEBUG

void Vquadra_top___024root___eval(Vquadra_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___eval\n"); );
    // Init
    IData/*31:0*/ __VnbaIterCount;
    CData/*0:0*/ __VnbaContinue;
    // Body
    __VnbaIterCount = 0U;
    __VnbaContinue = 1U;
    while (__VnbaContinue) {
        if (VL_UNLIKELY((0x64U < __VnbaIterCount))) {
#ifdef VL_DEBUG
            Vquadra_top___024root___dump_triggers__nba(vlSelf);
#endif
            VL_FATAL_MT("quadra_top.sv", 3, "", "NBA region did not converge.");
        }
        __VnbaIterCount = ((IData)(1U) + __VnbaIterCount);
        __VnbaContinue = 0U;
        vlSelf->__VactIterCount = 0U;
        vlSelf->__VactContinue = 1U;
        while (vlSelf->__VactContinue) {
            if (VL_UNLIKELY((0x64U < vlSelf->__VactIterCount))) {
#ifdef VL_DEBUG
                Vquadra_top___024root___dump_triggers__act(vlSelf);
#endif
                VL_FATAL_MT("quadra_top.sv", 3, "", "Active region did not converge.");
            }
            vlSelf->__VactIterCount = ((IData)(1U) 
                                       + vlSelf->__VactIterCount);
            vlSelf->__VactContinue = 0U;
            if (Vquadra_top___024root___eval_phase__act(vlSelf)) {
                vlSelf->__VactContinue = 1U;
            }
        }
        if (Vquadra_top___024root___eval_phase__nba(vlSelf)) {
            __VnbaContinue = 1U;
        }
    }
}

#ifdef VL_DEBUG
void Vquadra_top___024root___eval_debug_assertions(Vquadra_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___eval_debug_assertions\n"); );
    // Body
    if (VL_UNLIKELY((vlSelf->clk & 0xfeU))) {
        Verilated::overWidthError("clk");}
    if (VL_UNLIKELY((vlSelf->rst_b & 0xfeU))) {
        Verilated::overWidthError("rst_b");}
    if (VL_UNLIKELY((vlSelf->x & 0xff000000U))) {
        Verilated::overWidthError("x");}
    if (VL_UNLIKELY((vlSelf->x_dv & 0xfeU))) {
        Verilated::overWidthError("x_dv");}
}
#endif  // VL_DEBUG
