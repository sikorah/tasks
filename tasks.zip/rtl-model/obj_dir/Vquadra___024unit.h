// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vquadra.h for the primary calling header

#ifndef VERILATED_VQUADRA___024UNIT_H_
#define VERILATED_VQUADRA___024UNIT_H_  // guard

#include "verilated.h"


class Vquadra__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vquadra___024unit final : public VerilatedModule {
  public:

    // INTERNAL VARIABLES
    Vquadra__Syms* const vlSymsp;

    // CONSTRUCTORS
    Vquadra___024unit(Vquadra__Syms* symsp, const char* v__name);
    ~Vquadra___024unit();
    VL_UNCOPYABLE(Vquadra___024unit);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
