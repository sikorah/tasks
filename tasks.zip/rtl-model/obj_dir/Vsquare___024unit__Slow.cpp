// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vsquare.h for the primary calling header

#include "Vsquare__pch.h"
#include "Vsquare__Syms.h"
#include "Vsquare___024unit.h"

void Vsquare___024unit___ctor_var_reset(Vsquare___024unit* vlSelf);

Vsquare___024unit::Vsquare___024unit(Vsquare__Syms* symsp, const char* v__name)
    : VerilatedModule{v__name}
    , vlSymsp{symsp}
 {
    // Reset structure values
    Vsquare___024unit___ctor_var_reset(this);
}

void Vsquare___024unit::__Vconfigure(bool first) {
    if (false && first) {}  // Prevent unused
}

Vsquare___024unit::~Vsquare___024unit() {
}
