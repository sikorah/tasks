// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vquadra.h for the primary calling header

#include "Vquadra__pch.h"
#include "Vquadra__Syms.h"
#include "Vquadra___024unit.h"

void Vquadra___024unit___ctor_var_reset(Vquadra___024unit* vlSelf);

Vquadra___024unit::Vquadra___024unit(Vquadra__Syms* symsp, const char* v__name)
    : VerilatedModule{v__name}
    , vlSymsp{symsp}
 {
    // Reset structure values
    Vquadra___024unit___ctor_var_reset(this);
}

void Vquadra___024unit::__Vconfigure(bool first) {
    if (false && first) {}  // Prevent unused
}

Vquadra___024unit::~Vquadra___024unit() {
}
