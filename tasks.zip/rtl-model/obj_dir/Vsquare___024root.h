// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vsquare.h for the primary calling header

#ifndef VERILATED_VSQUARE___024ROOT_H_
#define VERILATED_VSQUARE___024ROOT_H_  // guard

#include "verilated.h"


class Vsquare__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vsquare___024root final : public VerilatedModule {
  public:

    // DESIGN SPECIFIC STATE
    CData/*0:0*/ __VstlFirstIteration;
    CData/*0:0*/ __VicoFirstIteration;
    CData/*0:0*/ __VactContinue;
    VL_OUTW(sq,67,0,3);
    IData/*31:0*/ __VactIterCount;
    VL_IN64(x2,33,0);
    VlTriggerVec<1> __VstlTriggered;
    VlTriggerVec<1> __VicoTriggered;
    VlTriggerVec<0> __VactTriggered;
    VlTriggerVec<0> __VnbaTriggered;

    // INTERNAL VARIABLES
    Vsquare__Syms* const vlSymsp;

    // CONSTRUCTORS
    Vsquare___024root(Vsquare__Syms* symsp, const char* v__name);
    ~Vsquare___024root();
    VL_UNCOPYABLE(Vsquare___024root);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
