// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Symbol table internal header
//
// Internal details; most calling programs do not need this header,
// unless using verilator public meta comments.

#ifndef VERILATED_VQUADRA__SYMS_H_
#define VERILATED_VQUADRA__SYMS_H_  // guard

#include "verilated.h"

// INCLUDE MODEL CLASS

#include "Vquadra.h"

// INCLUDE MODULE CLASSES
#include "Vquadra___024root.h"
#include "Vquadra___024unit.h"

// SYMS CLASS (contains all model state)
class alignas(VL_CACHE_LINE_BYTES)Vquadra__Syms final : public VerilatedSyms {
  public:
    // INTERNAL STATE
    Vquadra* const __Vm_modelp;
    VlDeleter __Vm_deleter;
    bool __Vm_didInit = false;

    // MODULE INSTANCE STATE
    Vquadra___024root              TOP;

    // CONSTRUCTORS
    Vquadra__Syms(VerilatedContext* contextp, const char* namep, Vquadra* modelp);
    ~Vquadra__Syms();

    // METHODS
    const char* name() { return TOP.name(); }
};

#endif  // guard
