// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vsquare.h for the primary calling header

#include "Vsquare__pch.h"
#include "Vsquare__Syms.h"
#include "Vsquare___024root.h"

void Vsquare___024root___ctor_var_reset(Vsquare___024root* vlSelf);

Vsquare___024root::Vsquare___024root(Vsquare__Syms* symsp, const char* v__name)
    : VerilatedModule{v__name}
    , vlSymsp{symsp}
 {
    // Reset structure values
    Vsquare___024root___ctor_var_reset(this);
}

void Vsquare___024root::__Vconfigure(bool first) {
    if (false && first) {}  // Prevent unused
}

Vsquare___024root::~Vsquare___024root() {
}
