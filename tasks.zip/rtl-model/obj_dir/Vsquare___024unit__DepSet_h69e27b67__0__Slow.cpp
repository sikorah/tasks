// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vsquare.h for the primary calling header

#include "Vsquare__pch.h"
#include "Vsquare___024unit.h"

VL_ATTR_COLD void Vsquare___024unit___ctor_var_reset(Vsquare___024unit* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsquare__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vsquare___024unit___ctor_var_reset\n"); );
}
