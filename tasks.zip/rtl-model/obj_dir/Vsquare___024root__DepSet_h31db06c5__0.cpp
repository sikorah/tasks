// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vsquare.h for the primary calling header

#include "Vsquare__pch.h"
#include "Vsquare___024root.h"

VL_INLINE_OPT void Vsquare___024root___ico_sequent__TOP__0(Vsquare___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsquare__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsquare___024root___ico_sequent__TOP__0\n"); );
    // Init
    VlWide<3>/*95:0*/ __Vtemp_2;
    VlWide<3>/*95:0*/ __Vtemp_3;
    VlWide<3>/*95:0*/ __Vtemp_4;
    // Body
    __Vtemp_2[0U] = (IData)(vlSelf->x2);
    __Vtemp_2[1U] = (IData)((vlSelf->x2 >> 0x20U));
    __Vtemp_2[2U] = 0U;
    __Vtemp_3[0U] = (IData)(vlSelf->x2);
    __Vtemp_3[1U] = (IData)((vlSelf->x2 >> 0x20U));
    __Vtemp_3[2U] = 0U;
    VL_MUL_W(3, __Vtemp_4, __Vtemp_2, __Vtemp_3);
    vlSelf->sq[0U] = __Vtemp_4[0U];
    vlSelf->sq[1U] = __Vtemp_4[1U];
    vlSelf->sq[2U] = (0xfU & __Vtemp_4[2U]);
}

void Vsquare___024root___eval_ico(Vsquare___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsquare__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsquare___024root___eval_ico\n"); );
    // Body
    if ((1ULL & vlSelf->__VicoTriggered.word(0U))) {
        Vsquare___024root___ico_sequent__TOP__0(vlSelf);
    }
}

void Vsquare___024root___eval_triggers__ico(Vsquare___024root* vlSelf);

bool Vsquare___024root___eval_phase__ico(Vsquare___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsquare__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsquare___024root___eval_phase__ico\n"); );
    // Init
    CData/*0:0*/ __VicoExecute;
    // Body
    Vsquare___024root___eval_triggers__ico(vlSelf);
    __VicoExecute = vlSelf->__VicoTriggered.any();
    if (__VicoExecute) {
        Vsquare___024root___eval_ico(vlSelf);
    }
    return (__VicoExecute);
}

void Vsquare___024root___eval_act(Vsquare___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsquare__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsquare___024root___eval_act\n"); );
}

void Vsquare___024root___eval_nba(Vsquare___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsquare__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsquare___024root___eval_nba\n"); );
}

void Vsquare___024root___eval_triggers__act(Vsquare___024root* vlSelf);

bool Vsquare___024root___eval_phase__act(Vsquare___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsquare__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsquare___024root___eval_phase__act\n"); );
    // Init
    VlTriggerVec<0> __VpreTriggered;
    CData/*0:0*/ __VactExecute;
    // Body
    Vsquare___024root___eval_triggers__act(vlSelf);
    __VactExecute = vlSelf->__VactTriggered.any();
    if (__VactExecute) {
        __VpreTriggered.andNot(vlSelf->__VactTriggered, vlSelf->__VnbaTriggered);
        vlSelf->__VnbaTriggered.thisOr(vlSelf->__VactTriggered);
        Vsquare___024root___eval_act(vlSelf);
    }
    return (__VactExecute);
}

bool Vsquare___024root___eval_phase__nba(Vsquare___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsquare__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsquare___024root___eval_phase__nba\n"); );
    // Init
    CData/*0:0*/ __VnbaExecute;
    // Body
    __VnbaExecute = vlSelf->__VnbaTriggered.any();
    if (__VnbaExecute) {
        Vsquare___024root___eval_nba(vlSelf);
        vlSelf->__VnbaTriggered.clear();
    }
    return (__VnbaExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vsquare___024root___dump_triggers__ico(Vsquare___024root* vlSelf);
#endif  // VL_DEBUG
#ifdef VL_DEBUG
VL_ATTR_COLD void Vsquare___024root___dump_triggers__nba(Vsquare___024root* vlSelf);
#endif  // VL_DEBUG
#ifdef VL_DEBUG
VL_ATTR_COLD void Vsquare___024root___dump_triggers__act(Vsquare___024root* vlSelf);
#endif  // VL_DEBUG

void Vsquare___024root___eval(Vsquare___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsquare__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsquare___024root___eval\n"); );
    // Init
    IData/*31:0*/ __VicoIterCount;
    CData/*0:0*/ __VicoContinue;
    IData/*31:0*/ __VnbaIterCount;
    CData/*0:0*/ __VnbaContinue;
    // Body
    __VicoIterCount = 0U;
    vlSelf->__VicoFirstIteration = 1U;
    __VicoContinue = 1U;
    while (__VicoContinue) {
        if (VL_UNLIKELY((0x64U < __VicoIterCount))) {
#ifdef VL_DEBUG
            Vsquare___024root___dump_triggers__ico(vlSelf);
#endif
            VL_FATAL_MT("square.sv", 3, "", "Input combinational region did not converge.");
        }
        __VicoIterCount = ((IData)(1U) + __VicoIterCount);
        __VicoContinue = 0U;
        if (Vsquare___024root___eval_phase__ico(vlSelf)) {
            __VicoContinue = 1U;
        }
        vlSelf->__VicoFirstIteration = 0U;
    }
    __VnbaIterCount = 0U;
    __VnbaContinue = 1U;
    while (__VnbaContinue) {
        if (VL_UNLIKELY((0x64U < __VnbaIterCount))) {
#ifdef VL_DEBUG
            Vsquare___024root___dump_triggers__nba(vlSelf);
#endif
            VL_FATAL_MT("square.sv", 3, "", "NBA region did not converge.");
        }
        __VnbaIterCount = ((IData)(1U) + __VnbaIterCount);
        __VnbaContinue = 0U;
        vlSelf->__VactIterCount = 0U;
        vlSelf->__VactContinue = 1U;
        while (vlSelf->__VactContinue) {
            if (VL_UNLIKELY((0x64U < vlSelf->__VactIterCount))) {
#ifdef VL_DEBUG
                Vsquare___024root___dump_triggers__act(vlSelf);
#endif
                VL_FATAL_MT("square.sv", 3, "", "Active region did not converge.");
            }
            vlSelf->__VactIterCount = ((IData)(1U) 
                                       + vlSelf->__VactIterCount);
            vlSelf->__VactContinue = 0U;
            if (Vsquare___024root___eval_phase__act(vlSelf)) {
                vlSelf->__VactContinue = 1U;
            }
        }
        if (Vsquare___024root___eval_phase__nba(vlSelf)) {
            __VnbaContinue = 1U;
        }
    }
}

#ifdef VL_DEBUG
void Vsquare___024root___eval_debug_assertions(Vsquare___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsquare__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsquare___024root___eval_debug_assertions\n"); );
    // Body
    if (VL_UNLIKELY((vlSelf->x2 & 0ULL))) {
        Verilated::overWidthError("x2");}
}
#endif  // VL_DEBUG
