// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vsquare.h for the primary calling header

#ifndef VERILATED_VSQUARE___024UNIT_H_
#define VERILATED_VSQUARE___024UNIT_H_  // guard

#include "verilated.h"


class Vsquare__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vsquare___024unit final : public VerilatedModule {
  public:

    // INTERNAL VARIABLES
    Vsquare__Syms* const vlSymsp;

    // CONSTRUCTORS
    Vsquare___024unit(Vsquare__Syms* symsp, const char* v__name);
    ~Vsquare___024unit();
    VL_UNCOPYABLE(Vsquare___024unit);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
