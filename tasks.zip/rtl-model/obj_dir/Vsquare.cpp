// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Model implementation (design independent parts)

#include "Vsquare__pch.h"

//============================================================
// Constructors

Vsquare::Vsquare(VerilatedContext* _vcontextp__, const char* _vcname__)
    : VerilatedModel{*_vcontextp__}
    , vlSymsp{new Vsquare__Syms(contextp(), _vcname__, this)}
    , sq{vlSymsp->TOP.sq}
    , x2{vlSymsp->TOP.x2}
    , rootp{&(vlSymsp->TOP)}
{
    // Register model with the context
    contextp()->addModel(this);
}

Vsquare::Vsquare(const char* _vcname__)
    : Vsquare(Verilated::threadContextp(), _vcname__)
{
}

//============================================================
// Destructor

Vsquare::~Vsquare() {
    delete vlSymsp;
}

//============================================================
// Evaluation function

#ifdef VL_DEBUG
void Vsquare___024root___eval_debug_assertions(Vsquare___024root* vlSelf);
#endif  // VL_DEBUG
void Vsquare___024root___eval_static(Vsquare___024root* vlSelf);
void Vsquare___024root___eval_initial(Vsquare___024root* vlSelf);
void Vsquare___024root___eval_settle(Vsquare___024root* vlSelf);
void Vsquare___024root___eval(Vsquare___024root* vlSelf);

void Vsquare::eval_step() {
    VL_DEBUG_IF(VL_DBG_MSGF("+++++TOP Evaluate Vsquare::eval_step\n"); );
#ifdef VL_DEBUG
    // Debug assertions
    Vsquare___024root___eval_debug_assertions(&(vlSymsp->TOP));
#endif  // VL_DEBUG
    vlSymsp->__Vm_deleter.deleteAll();
    if (VL_UNLIKELY(!vlSymsp->__Vm_didInit)) {
        vlSymsp->__Vm_didInit = true;
        VL_DEBUG_IF(VL_DBG_MSGF("+ Initial\n"););
        Vsquare___024root___eval_static(&(vlSymsp->TOP));
        Vsquare___024root___eval_initial(&(vlSymsp->TOP));
        Vsquare___024root___eval_settle(&(vlSymsp->TOP));
    }
    VL_DEBUG_IF(VL_DBG_MSGF("+ Eval\n"););
    Vsquare___024root___eval(&(vlSymsp->TOP));
    // Evaluate cleanup
    Verilated::endOfEval(vlSymsp->__Vm_evalMsgQp);
}

//============================================================
// Events and timing
bool Vsquare::eventsPending() { return false; }

uint64_t Vsquare::nextTimeSlot() {
    VL_FATAL_MT(__FILE__, __LINE__, "", "%Error: No delays in the design");
    return 0;
}

//============================================================
// Utilities

const char* Vsquare::name() const {
    return vlSymsp->name();
}

//============================================================
// Invoke final blocks

void Vsquare___024root___eval_final(Vsquare___024root* vlSelf);

VL_ATTR_COLD void Vsquare::final() {
    Vsquare___024root___eval_final(&(vlSymsp->TOP));
}

//============================================================
// Implementations of abstract methods from VerilatedModel

const char* Vsquare::hierName() const { return vlSymsp->name(); }
const char* Vsquare::modelName() const { return "Vsquare"; }
unsigned Vsquare::threads() const { return 1; }
void Vsquare::prepareClone() const { contextp()->prepareClone(); }
void Vsquare::atClone() const {
    contextp()->threadPoolpOnClone();
}

//============================================================
// Trace configuration

VL_ATTR_COLD void Vsquare::trace(VerilatedVcdC* tfp, int levels, int options) {
    vl_fatal(__FILE__, __LINE__, __FILE__,"'Vsquare::trace()' called on model that was Verilated without --trace option");
}
